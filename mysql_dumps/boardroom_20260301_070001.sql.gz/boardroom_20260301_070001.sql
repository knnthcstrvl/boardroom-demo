/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: boardroom
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_rooms`
--

DROP TABLE IF EXISTS `meeting_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_rooms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `timezone` varchar(255) NOT NULL DEFAULT 'Asia/Manila',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_rooms`
--

LOCK TABLES `meeting_rooms` WRITE;
/*!40000 ALTER TABLE `meeting_rooms` DISABLE KEYS */;
INSERT INTO `meeting_rooms` VALUES
(1,'Board Room','Asia/Manila',1,'2026-02-24 10:57:45','2026-02-24 10:57:45');
/*!40000 ALTER TABLE `meeting_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_02_04_000003_add_admin_and_azure_fields_to_users_table',1),
(5,'2026_02_04_000004_create_meeting_rooms_table',1),
(6,'2026_02_04_000005_create_reservations_table',1),
(7,'2026_02_04_000006_add_requester_fields_to_reservations_table',1),
(8,'2026_02_04_000007_insert_default_meeting_room',1),
(9,'2026_02_04_000008_create_reservation_events_table',1),
(10,'2026_02_04_000009_add_reservation_query_indexes',1),
(11,'2026_02_04_000010_add_repeat_fields_to_reservations_table',1),
(12,'2026_02_11_000001_add_requester_attendees_to_reservations_table',1),
(13,'2026_02_11_000002_add_repeat_unit_to_reservations_table',1),
(14,'2026_02_12_000001_add_microsoft_avatar_fields_to_users_table',1),
(15,'2026_02_23_000001_create_user_events_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation_events`
--

DROP TABLE IF EXISTS `reservation_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint(20) unsigned DEFAULT NULL,
  `meeting_room_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservation_events_reservation_id_foreign` (`reservation_id`),
  KEY `reservation_events_type_index` (`type`),
  KEY `reservation_events_room_id_idx` (`meeting_room_id`,`id`),
  CONSTRAINT `reservation_events_meeting_room_id_foreign` FOREIGN KEY (`meeting_room_id`) REFERENCES `meeting_rooms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reservation_events_reservation_id_foreign` FOREIGN KEY (`reservation_id`) REFERENCES `reservations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_events`
--

LOCK TABLES `reservation_events` WRITE;
/*!40000 ALTER TABLE `reservation_events` DISABLE KEYS */;
INSERT INTO `reservation_events` VALUES
(1,1,1,'reservation.created','2026-02-24 11:34:50','2026-02-24 11:34:50'),
(2,2,1,'reservation.created','2026-02-24 13:47:22','2026-02-24 13:47:22'),
(3,6,1,'reservation.created','2026-02-24 15:01:36','2026-02-24 15:01:36');
/*!40000 ALTER TABLE `reservation_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `meeting_room_id` bigint(20) unsigned NOT NULL,
  `requested_by` bigint(20) unsigned DEFAULT NULL,
  `requester_email` varchar(255) DEFAULT NULL,
  `requester_department` varchar(255) DEFAULT NULL,
  `requester_attendees` smallint(5) unsigned DEFAULT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `rejected_reason` text DEFAULT NULL,
  `repeat_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `repeat_unit` varchar(255) NOT NULL DEFAULT 'week',
  `repeat_weeks` int(10) unsigned DEFAULT NULL,
  `repeat_days` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`repeat_days`)),
  `repeat_start_date` date DEFAULT NULL,
  `repeat_series_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservations_approved_by_foreign` (`approved_by`),
  KEY `reservations_meeting_room_id_start_at_end_at_index` (`meeting_room_id`,`start_at`,`end_at`),
  KEY `reservations_status_index` (`status`),
  KEY `reservations_requested_by_foreign` (`requested_by`),
  KEY `reservations_room_status_range_idx` (`meeting_room_id`,`status`,`start_at`,`end_at`),
  KEY `reservations_repeat_series_id_index` (`repeat_series_id`),
  CONSTRAINT `reservations_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reservations_meeting_room_id_foreign` FOREIGN KEY (`meeting_room_id`) REFERENCES `meeting_rooms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reservations_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES
(1,1,NULL,'email@email.com','Academic Department',5,NULL,'Test','2026-02-25 12:00:00','2026-02-25 13:00:00','pending',NULL,0,'week',NULL,NULL,NULL,NULL,'2026-02-24 11:34:50','2026-02-24 11:34:50'),
(2,1,NULL,'email@email.com','Academic Department',5,NULL,'Test Recurring','2026-02-25 10:00:00','2026-02-25 11:00:00','pending',NULL,1,'week',2,'[3,5]','2026-02-25','3a1d73f3-3209-4ff7-bdc3-13942d288e7f','2026-02-24 13:47:22','2026-02-24 13:47:22'),
(3,1,NULL,'email@email.com','Academic Department',5,NULL,'Test Recurring','2026-02-27 10:00:00','2026-02-27 11:00:00','pending',NULL,1,'week',2,'[3,5]','2026-02-25','3a1d73f3-3209-4ff7-bdc3-13942d288e7f','2026-02-24 13:47:22','2026-02-24 13:47:22'),
(4,1,NULL,'email@email.com','Academic Department',5,NULL,'Test Recurring','2026-03-04 10:00:00','2026-03-04 11:00:00','pending',NULL,1,'week',2,'[3,5]','2026-02-25','3a1d73f3-3209-4ff7-bdc3-13942d288e7f','2026-02-24 13:47:22','2026-02-24 13:47:22'),
(5,1,NULL,'email@email.com','Academic Department',5,NULL,'Test Recurring','2026-03-06 10:00:00','2026-03-06 11:00:00','pending',NULL,1,'week',2,'[3,5]','2026-02-25','3a1d73f3-3209-4ff7-bdc3-13942d288e7f','2026-02-24 13:47:22','2026-02-24 13:47:22'),
(6,1,NULL,'email@email.com','Academic Department',4,NULL,'Test','2026-02-26 13:00:00','2026-02-26 14:00:00','pending',NULL,0,'week',NULL,NULL,NULL,NULL,'2026-02-24 15:01:36','2026-02-24 15:01:36');
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('41HxbjF9bMcZ5A8yvDd2QpJflCdmCQg1jinKTrcc',NULL,'172.16.14.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0','ZXlKcGRpSTZJamx5WlN0RFRHbEliMVFyZERkTE4yVkpOVFlyTDNjOVBTSXNJblpoYkhWbElqb2lXVEphZHpoc1psZFlSMWc1WlRaRlJqbHdjMWx4UTJWTWVIWnlOVWhOWkhWU1IySnFhVUpwYXpFd2VuTldkbXcxTldkNFNWRmpNVzFSTm5KYWJVbzVZbFZ5TVZOeVNWTklTamREWkRKc1VVcHZlR2RZWTA5WWFUQlhXVkZCZGtOQlpYWlNNRGhrTDNSNGRsaENhbUk0YTNoUU1FSlFPRTlRWWtwa01EUTNaMmRPZEVKRFpYcEpUbWhEV21NeVdDOUtibXM1ZUhOeGFpOU9WMjUxVVZkMEszRkJhRmxMVWpSTWRWZzRQU0lzSW0xaFl5STZJakptTVRNNE56YzROV1ZqTnpNd1pUWmhZV1kzWVdZNU0yWTNabUpqTWpFd1pqQTBPV0k1WlRJd1pUUm1aV0k0WlRBd05EVmtNRGhqWW1ZNE56ZG1ZekVpTENKMFlXY2lPaUlpZlE9PQ==',1772068362),
('9nWssbkF8ab0UXcgiJMBVp6aGdlROPRU1gyc9BkS',NULL,'172.16.11.251','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0','ZXlKcGRpSTZJblF3VG1KYWRHbFBjemw1UW1obEwxUk5WRFJ3Um1jOVBTSXNJblpoYkhWbElqb2lSRlZIUmxGc1NFTkxOM015ZWt0cU0xZGFUVEF4VDJJdlJuSlJUWFo1UTBZNGJUZzFWRTFwWkVWa1YzcFRkMnAzTUZKb2RIZFBUMWw0VkM5bWNYTnpXVmd2VFVscFRVOWhkRlV2VlV4eFRWRjBkMmxzUlVST2RHRTRhMmRtZFZOTmFXODVhbmxDVWk5aFQzQnBkbTQyV1doUk4wb3hhSHAyZWpadGNWWndVbE5LYkVwR2FHbElOMlZGVG1neFIyUldORzl3Wm1WUVlteHRNVzFCVlUxR1ZqWlRWbGdyV0dnNVJ6Vk1ZbGRFY1RsUGFqVTNjamRqZVV4bk1URTVVa3hwY21adUx6RlhaVXROYzI5RlpDc3llalF6T0UxdVpYaHljMUZpT0dsVVVGRm9hVTlOV21Oc1RsVmliSGh3TUhoMVdHVjJka0ZNYlc5Sk0wTjVUeTlLYzJORGNVWnZUekJTVXpCV1VETnBjVTVpVFU4d1NUUmlLM0ZZZDB0UWVXOVZjMFV5WlVkWFIzRlRhME4xYXpGNWJYTnpkaXRoZGpaWVFVTXZUMkpMTlhJaUxDSnRZV01pT2lJeU5EazFOV1k0WTJKa05qYzBPVFpqT1RFeVpXRmlNV0ZqWldReU1EY3dPREUxTkdOak5qazNNemd4TXpCak0yVXdOamt6WTJaallqWTFNakF4WW1FNUlpd2lkR0ZuSWpvaUluMD0=',1772156860),
('B5m2Sa4ZvdJ2O2kxKXynm0uCeKGQ2BBXGIUEP0wx',NULL,'172.16.13.103','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0','ZXlKcGRpSTZJbVZFTkdkT1QwMDBNWFE0YVN0SmJuVlNXR2d6TjBFOVBTSXNJblpoYkhWbElqb2lUM0ZrUmpaTGNVZ3pZbEZLWm1FMVpFZEJZV1J2TmtkM2VYWndRM1ZNYjJsU1EyMWxiV0pvZFZGbVprRkNNbEZEU1VGNFpUSnNSR3RQVGxwQ09HRkNlbTVYVFhBdk0xUXlUV0ZFUjFWbGFEbGxiVU5HU1VwcmJIWXZkV0pXTW1ZMlJHRjZNbU0xU1RVcmRIWktWRWswYzBZek5EUTVXRlp5ZWpoWWJ6QTVialp2TTFGeU5VcHNVRGxTSzBoVlUwUTVjV0pyZVU5SFZYSkhUV0YzVW13MEx5OTNWeTh6TW5WYVMxQnZQU0lzSW0xaFl5STZJalF6T0dJMFl6azRNbVJsTVRaaVpHWTBZemhoTUdFM09HUTRNV0V6TjJVd01ERTBNR1EwTm1Kak1XVm1NekkyTnpGbU1tTmhOelptWmpoa05XSTJNemdpTENKMFlXY2lPaUlpZlE9PQ==',1772084890),
('Of9NuPONds0qrwEXV78UbGVikKJeiNjJUELu7E4i',NULL,'172.16.14.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','ZXlKcGRpSTZJbkZ1VW5KS1NTOUJZelExUVdjdlIyRkpUaXR6V2tFOVBTSXNJblpoYkhWbElqb2laM3BKZERWMGRIcENibTl2TVZOWWNua3ZMM2cxVkdrd2MxRmFNa3QwTlVjMFltZEpWVGd2T1UxamNIbGlSV1pKWTJkSVVVbENWbmxSWVVGSFF6TlVVQ3RtYW5JMVYwWkhTVFJxZDNZMWQySk5NblpCVUdaelJFaExORFF5TmxKUFFrMXdOblkwUWxGeVZURXdXRmhvVEVGUlJXNDRlVkpPU0ZaM1lXc3JPVlYxVUZNek5sVkxUQ3RSUW5CcUwzSjNjekpWUmpObWRHTjVhV3A2Y1RoWWVDdEJjMXBQUkUxWFNHWnBUSEJoUkdWWGFHVk9SRTlVTTBOUFpEazNRMDR6V20xdWVYSkxMemd5ZFdWU1RFeHJlV1pIVmxoNE9XRnFPWGxwTjFkR2RFTjRWMUJKY0c5dGF5dGtibGxPWW1kamJWUjFRV3N3YTBGS2RUVXpja00zWmtKWVZTOUtlVGc0TW00dkwxbEZSR3BzY1ZaTVR6RkhNVUZhVmk5Rk1GZE1ORGxLZWpGUlFXZG1NMUJsUTBKUFlrbFlhVkp2WjNKWmRYSlVNVU5tVVZKNFJFZE9NMHhHY0c1Rk1qbHZVbFpNVmtoak5XZEdSM1Z0UmtsdFFUZFVjekZ6UWtvMVlXcDJNRzh6U0c1cVpEVk1ha0ZzS3pBd1MxaE9TV3BrZFZWcU56Um9VaXRuZGk5TmRYRTNUM0ExVTNReFRHd3lPSGxOVm5kRE9EUk5ObTVZUjJaMU4yVlpUWGM0YjBOMGNTdExNWE5ZVVRSWWFYSjRjbFJVTkZKSE9FNDNaWFo1UTAwMGNFdDFNbVpzU25KRlNYSkdNbTVVV1RWdmJ6QlBaVWt6TDNkVVVtSnhVRVJSTnpNMWNIaDZWRFpHZVdoaVkwWldSRFo2VFhGYU0yeE9URnByTmxaNlVXVjBUVEY2TjJzNWJtZ3pVbkprZEVReGFUTlNSVzF2TURRM1FVSTRWRXhDYW1oQlBTSXNJbTFoWXlJNkltRmtOMk00Tm1JeFlXVTVPVEl3T0dFMk1XTXlPRFEwWldWaU1XWm1ZVE00WmpJMVpXRTFaR1F5T1RVeFlXVTNZVFpqTkdSa09XTTRaVFk0TkRJME4yTWlMQ0owWVdjaU9pSWlmUT09',1772088617),
('Os6ruRAKYuMbhcAXo6qNHp8inctK0JAvDJBqRMfN',NULL,'172.16.14.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','ZXlKcGRpSTZJbVpzZEZaSlUxWlJUVkZvVEVGRmFGbFVPWFZ0VUZFOVBTSXNJblpoYkhWbElqb2lNSFV2Y20xblNUZEhOM05yYkRKa01EbEdhR0pHZDJvNVpHSjJRMHA2VjBZM2NXZFpRa1ZhY0VSUGQxRlJUamxLVTBNNE5WZHNjRmR5ZUZKT2EwZFRTSFZ6UmxSS1kxQmhlRU5OV0RnclozSkVaaTlGVldOWFQyNUhhSFJ4VjJaVlNUVkZlRE5NV0U4elVVRjNkMEl3TVVoaU4xRk9WMnBFU1U5R0wxQktVMUY2TWxWS0swaGxUMWg0ZWsxU1V6TXZXVUpWUWpnNVJFOXNaSGgwZEZkMlpFRmhRa2xNT0hWblJEUlZNbWhRVjFVMmIwdEpiRkUyZVRGM05FUlpTRWN2Ylhob1dXVnZlbEV5ZDI1dFJITXhUREJoVTNoeU1YSmlNbWh2YzJGdVdsbHBUR1ZUTUdJM1ZtUkhORFl5WVhKbU5ETkdLMEZCYUVaaU1uUlJlRGhCUlRGbmRrTnJXVnA0TjBOemRVMTBhVTFDYXpkWU9VZzVPR1EwYUVveU1VNTBiRGRpTDBWd1RqbENia2wxT1V4aFdsaHlWWFZuYTNkd2QwaEtNVGh2VDNjaUxDSnRZV01pT2lJeFltWXlNMkZqT1dNd1lUZG1NVGt5T0RGa1pHRXdNVEV4WTJSaE1Ua3pPVGc1WlROa01EUmhPVFZoWVdWa05EazBOREE1WldRMk1Ea3hNVFF4T0RSbUlpd2lkR0ZuSWpvaUluMD0=',1772157704),
('vI2qGX8VX7LEBSOtjOAtlMPXSDjV0JObBGeOvnIk',NULL,'172.16.14.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','ZXlKcGRpSTZJa1JKT1UwNFVHWTNXU3MyZFU5M1QwTXlaVTFsUzFFOVBTSXNJblpoYkhWbElqb2lUbTFrWjJ4SU5VWjNhemd6WlZkWlVteElaVmgyT0ZkclVIWjJOVGh6WTJsWmRrdFBWMEZMYVdWaVYwSnVOVUpsUkV4TlVIQkhPVTkzVEdsQlJWZzRibUUzVUc5TlZqVXlkVGxYY21ReFpUaDVla1ZKZDJWcE5HVm5iMEoxV2pOdlZsVlJaekJZTDNGWmRWTldUVTVrTTBnMVpqQTFVV3BvU1dkbEsweFhiRWRKWlZOcVkxSnpVRGhVUlVsSlZVOU1VbVpSYmtoRFRsZDZXVWsxYmtwd2RHWnRRbU42TUVVNFMyUlZQU0lzSW0xaFl5STZJakEyWXpZNU5ESXhOMkl6Wm1WbFpESXdaVE5sWm1VMFlqYzVOams1WkRGbFpXSTROVFl4WVRSa09ETXlZamRqWlRnM05UVm1NbUkyT1dabU1qUXdPR1lpTENKMFlXY2lPaUlpZlE9PQ==',1772071099);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_events`
--

DROP TABLE IF EXISTS `user_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_events_user_id_index` (`user_id`),
  KEY `user_events_type_index` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_events`
--

LOCK TABLES `user_events` WRITE;
/*!40000 ALTER TABLE `user_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `azure_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `access` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`access`)),
  `microsoft_avatar_mime` varchar(80) DEFAULT NULL,
  `microsoft_avatar_base64` longtext DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_azure_id_unique` (`azure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'boardroom'
--

--
-- Dumping routines for database 'boardroom'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-28 23:00:02
